# @shakilabs/ui

ShakiLabs 서비스가 공유하는 Vue 3 디자인 primitive 패키지다.

> 버전을 올려 12개 앱에 내보낼 때는 [`docs/UI_RELEASE.md`](../../docs/UI_RELEASE.md)의 체크리스트를 따른다.
> 소비 저장소의 `client/vendor/README.md`는 손으로 고치지 않고 `npm run vendor:readme`로 생성한다.

## 목표

- 앱별 브랜드 컬러를 유지하면서 타이포그래피와 기본 UI 동작을 통일한다.
- Tailwind 설정과 무관하게 `00`~`11`에서 같은 컴포넌트를 사용한다.
- 패키지 버전을 고정해 한 앱씩 안전하게 마이그레이션한다.

## Angular Editorial 버전 계약

- 구조 Surface는 1px 경계를 기본으로 하고, 반경은 v3 §2.4 표를 따른다 — 컨테이너 12px(`--sh-panel-radius`) · 카드성 블록 8px(`--sh-card-radius`) · 칩·인풋 4px(`--sh-radius-sm`). 그림자는 여전히 쓰지 않는다(§2.4 shadow.none): 위계는 반경·구분선·여백으로만 만든다.
- Button/Input은 별도 2px 반경을 유지해 카드와 control을 구분한다.
- shadow는 떠 있는 overlay에만 허용한다.
- control은 최소 44px 높이와 2px focus outline을 유지한다.
- 본문은 16px를 유지하고 큰 display 타이포를 절제한다.
- Tailwind, Radix Vue, CVA를 런타임 의존성으로 요구하지 않는다.
- 0.2.5부터 소비 앱의 평면 카드·control·focus 계약도 패키지 CSS 한 곳에서 관리한다.
- 0.2.6부터 반복 결과 배너는 `ShSummaryBanner`의 의미론적 description list를 사용한다.
- 0.2.7부터 desktop 전용 partial radius와 `rounded-md`도 Angular 계약에 포함한다.
- 0.2.8부터 Slider는 대비가 선명한 핸들과 현재 값까지 채워지는 진행 구간을 공통으로 제공한다.
- 0.2.9부터 Slider 아래의 빠른 선택은 `ShPresetGroup`의 동기화된 pill 버튼을 사용한다.
- 0.2.10부터 각진 버튼 호환 규칙에서도 `[data-sh-pill]`의 pill 형태를 보존한다.
- 0.3.4부터 숫자·문자·불리언 입력 프리셋은 같은 고대비 `ShPresetGroup` 칩을 사용한다.
- 0.3.6부터 결과 구성 막대와 한도 진행률은 얇고 각진 트랙, 의미 기반 색상, 명시적 범례를 공유한다.
- 0.3.7부터 프리셋은 44px 터치 영역 안에 32px 시각 칩을 그려 모바일 조작성은 유지하면서 밀도를 높인다.
- 0.3.11부터 차트 막대 rect에는 반경을 두지 않는다. 막대 SVG는 `preserveAspectRatio="none"`이라 viewBox 단위 `rx`가 가로 배율만큼 늘어나 같은 컴포넌트 안에서도 막대 폭에 따라 둥글기가 달라졌다. 반경은 왜곡되지 않는 트랙 CSS(`--sh-radius-sm`, 0.3.30부터 4px)에서만 준다.
- 0.3.12부터 `[role="progressbar"]`는 **알약 예외 셀렉터가 아니다**. a11y 속성을 스타일 훅으로 쓰면 각형이어야 할 막대까지 잡힌다 — 실제로 `ShBulletProgress`의 트랙이 `compatibility.css`의 `!important`에 덮여 12개 앱에서 알약으로 나갔고 0.3.11의 반경 수정이 무효화돼 있었다. 알약은 `[data-sh-pill]`/`.sh-pill`로만 옵트인한다.
- 0.3.12부터 `ShBulletProgress`는 `polarity`(`higher-worse` 기본 · `lower-better`)와 `primary`(`percent` 기본 · `value`)를 받는다. 같은 채움 비율이 화면에 따라 정반대 의미를 가지므로(한도 사용률 vs 회수 시점) 색과 1차 수치를 호출부가 정한다. 기본값은 기존 호출부와 동일하다.
- 0.3.11부터 meter 막대는 값이 전부 0이어도 `aria-valuemax > aria-valuemin`을 보장한다(축이 붕괴하면 상한을 하한+1로 둔다). 값 0의 막대 폭은 그대로 0이다.

## 0.3 Primary Navigation

- `ShPrimaryNavigation`은 모바일 grid, 데스크톱 가로 스크롤, 활성 표시와 접근성만 담당한다.
- Vue Router를 직접 의존하지 않고 소비 앱이 `linkComponent`로 `RouterLink`를 주입한다.
- 링크가 아닌 메뉴 동작은 `action` 항목으로 선언해 네이티브 버튼 의미를 유지한다.
- 메뉴 구성, 활성 경로 판정, 서비스 홈 이동과 분석 이벤트는 소비 앱에 둔다.
- 모바일 메뉴가 많은 앱은 `mobileItems`로 우선 항목을 전달하고 2열 또는 3열을 선택한다.
- 데스크톱 메뉴는 960px 본문 기준선에서 왼쪽 정렬하며, 다른 본문 폭은 `--sh-navigation-desktop-max-width`와 `--sh-navigation-desktop-padding`으로 맞춘다.

## 현재 API

- `ShButton`: primary, secondary, ghost, danger
- `ShSurface`: plain, outlined, raised
- `ShSurfaceHeader`, `ShSurfaceBody`, `ShSurfaceFooter`
- `ShText`: display, title, heading, body, caption, label
- `ShSeparator`: horizontal, vertical과 semantic/decorative 모드
- `ShTable`과 Header, Body, Footer, Row, Head, Cell, Caption, Empty
- `ShField`, `ShLabel`, `ShInput`, `ShSelect`, `ShTextarea`, Hint, Error
- `ShSlider`: 네이티브 range 의미론, 숫자 v-model, 진행 구간, 키보드·포커스 상태
- `ShPresetGroup`: 선택 상태와 `aria-pressed`, wrap·가로 스크롤을 제공하는 빠른 선택 버튼 그룹
- `ShStepper`: ± 증감 버튼(44px 히트)과 tabular 값 표시, 길게 누름 반복 — 검증·포맷·스텝 정책은 앱 소유
- `ShToggleGroup`: 2~4개 배타 선택 radiogroup, 프리셋 칩 시각 재사용, 화살표 키 순회
- `ShBadge`, `ShCallout`, `ShEmptyState`, `ShSkeleton`
- `ShPrimaryNavigation`: 2·3열 모바일 메뉴와 가로 스크롤 데스크톱 메뉴
- `ShBreakdownBar`: 구성 비율, 색 점 범례, 값 formatter, plain·outlined surface
- `ShBulletProgress`: 현재값과 기준 한도의 비율, 끝 기준선·라벨, 초과 상태
- `ShMetricBars`: 지표별 독립 축 비교 막대, positive·signed 도메인, `role="meter"`, `#header` 슬롯
- `ShRankedBars`: 순위 막대. `value: null`(산출 불가)은 폭 0으로 남기고 목록에서 지우지 않는다

### Breakdown 세그먼트 병합 가이드

- ratio 1% 미만 세그먼트는 앱에서 "기타"로 병합해 전달한다 — chartMath는 병합을 계산하지 않는다 (계산은 앱 소유).
- 바에서 세그먼트가 최소 시각폭 4px을 확보하지 못하면 병합 대상으로 본다. 범례 상세가 필요하면 범례에서만 분리 표기한다.

## 사용 예시

```ts
import { ShButton, ShSurface, ShText } from "@shakilabs/ui";
import "@shakilabs/ui/styles.css";
```

```vue
<ShSurface padding="lg">
  <ShText as="h2" variant="title">비교 결과</ShText>
  <ShText tone="muted">같은 기준으로 계산한 결과입니다.</ShText>
  <ShButton>자세히 보기</ShButton>
</ShSurface>
```

```vue
<ShPrimaryNavigation
  :items="navigationItems"
  :active-key="activeItem?.key"
  :link-component="RouterLink"
  @select="trackNavigation"
/>
```

## 테마 연결

기존 앱의 `--background`, `--foreground`, `--card`, `--primary`, `--border` 토큰을 자동으로 참조한다. 필요한 경우 앱 루트에서 `--sh-*` 값을 직접 덮어쓸 수 있다.

```css
:root {
  --sh-card-radius: 0.5rem;
  --sh-panel-radius: 0.75rem;
  --sh-radius-sm: 0.25rem;
  --sh-radius-md: 0.5rem;
  --sh-color-primary: hsl(var(--primary));
}
```

## 데이터와 폼 경계

- Table은 표현과 접근성만 담당하고 정렬, 필터, 페이지네이션은 앱에 둔다.
- Field primitive는 validation 정책과 숫자 변환을 소유하지 않는다.
- Slider는 단일 숫자 입력과 시각 상태만 담당한다.
- PresetGroup은 선택·반응형 표현만 담당하며, 금액·비율 라벨과 프리셋 데이터는 소비 앱에 둔다.
- Accordion, Dialog, Sheet 같은 focus 관리형 컴포넌트는 별도 패키지 결정을 기다린다.
- 기존 앱의 Header, SEO, 광고, 공유와 도메인 로직은 패키지로 이동하지 않는다.
- 모든 소비 앱은 exact version과 artifact checksum을 사용한다.

## 호환 레이어와 예외

- `.design-system-shell` 아래의 기존 `retro-*` 및 Tailwind surface는 공통 호환 레이어가 같은 시각 계약으로 정규화한다.
- 앱별 `design-system.css`에 공통 규칙을 복제하지 않는다.
- pill은 `data-sh-pill` 또는 `.sh-pill`, 원형은 `data-sh-circle`로 명시한 경우에만 허용한다.
- radio, checkbox, slider thumb, spinner, avatar 이미지, progressbar는 원형 예외에 포함한다.
- Dialog와 AlertDialog만 overlay shadow를 사용할 수 있다.

## 비교 화면

운영 라우트와 분리된 playground에서 기존 장식형 패턴, Table, Form, 상태, 다크 토큰을 비교한다.

```bash
npm run build:playground
npm run preview:playground
```

## 0.3.30 — 카드 문법을 v3 §2.4 표로 되돌림

`--sh-card-radius: 0px`·`--sh-radius-*: 2px`의 근거로 CSS 주석이 지목하던 "각형 규약(ADR-002)"은
`docs/decisions/`에 **존재하지 않는 문서**다(002번은 Drizzle 채택건). 문서화되지 않은 값이 v3 §2.4
표(sm 4 · md 8 · lg 12)를 덮고 있었으므로 표를 정본으로 되돌렸다.

- 컨테이너(`.retro-panel`·`.retro-details`·`.retro-board-list`·`.retro-chart`·`.seo-rich-guide`)는
  `--sh-panel-radius`(12px), 그 안의 블록은 `--sh-card-radius`(8px). 바깥이 한 단계 크다.
- **카드 안 카드 금지**: `.retro-panel`/`.retro-details` 안에 중첩된 `.retro-panel-muted`·`.retro-stat`은
  테두리를 잃고 면으로만 구분된다(라이브 중첩 149곳: finance 25 · card 63 · invest 37 · loan 24).
  홀로 놓인 muted 패널은 테두리를 유지한다 — 캔버스 위에서 경계를 잃으면 안 되기 때문이다.
- `.retro-panel-content`·`.retro-titlebar` 패딩을 대칭(16/20px)으로. 앱 `@apply`는 (0,1,0)이라
  패키지 (0,2,0) 선언이 이긴다.
- **그림자는 넣지 않는다.** AWS 콘솔식 elevation을 따라가면 Archive 톤의 평평함이 사라진다.
  `box-shadow: none !important`는 그대로다.

## 0.3.35 — 본문 프레임을 하나로 (사용자 결정 2026-09-24)

v3 §2.7의 컨테이너 3역할(page 64rem · tool 72rem · prose 42rem)을 **폐지**했다.
역할별 폭을 가운데 정렬로 구현한 결과, 화면을 이동할 때마다 제목 시작 x가
**7가지(168·232·253·257·408·424·429px)**로 흩어졌다(라이브 23화면 실측, 1440px).
0.3.34는 홈에서 헤더까지 1024로 줄여 헤더 폭도 두 가지가 됐다.

- 모든 `.sh-container`는 **`--sh-container-frame`(72rem)** 하나를 쓴다. 헤더·2차 내비도 같다.
- `--tool`/`--page`/`--prose` 클래스와 `--sh-container-*` 토큰은 **마크업 호환용 별칭**이다.
  값은 전부 프레임이다 — 역할별로 다시 벌리면 계약 테스트가 막는다.
- 읽는 폭은 프레임을 좁히지 않고 **글줄만** 묶는다: `.sh-container--prose` 안의
  `h1~h4·p·ul·ol·dl·blockquote`에 `--sh-text-measure`(42rem). 가운데로 옮기지 않으니
  제목·본문이 로고와 같은 x에서 시작한다. 표는 묶지 않는다(스크롤 래퍼가 처리).
- 헤더 기준선(`--sh-header-content-width`)은 프레임에 고정. 페이지 내용으로 바꾸는
  `:has()` 규칙은 어느 스타일 파일에도 두지 않는다(전수 검사).

카드 안에 든 제목은 카드 패딩(20~24px)만큼 안쪽에서 시작하는 게 정상이다 — 정렬은
**카드 테두리(박스)**로 판정한다, 글자로 하지 않는다.

## 0.3.36 — `ShGapBars`: 1위 대비 차이 막대

seller "월 판매 손익 그래프"는 순이익 8,537,400 / 8,025,300 / 7,800,300원을 0부터 그려
**네 막대가 같은 길이로 보였다**(실제 차이 6~9%). 축을 잘라 차이를 키우면 막대 길이가 거짓말을 한다.
그래서 총액은 숫자로 두고, **1위와의 차이 자체를 0 기준선부터** 그리는 차트를 추가했다.

```vue
<ShGapBars
  title="월 순이익 — 1위와의 차이"
  :items="[{ key: 'smartstore', label: '스마트스토어', value: 8537400 }, …]"
  :format-value="formatWon"
  better="higher"
/>
```

- `better`: `"higher"`(순이익·환급액) 또는 `"lower"`(수수료·이자·비용). 1위 판정과 부호가 여기서 정해진다.
- 1위 행은 막대 없이 기준선 옆에 `기준`, 나머지는 **가장 큰 차이 대비 길이**의 회색 막대 + `−512,100원 −6.0%`.
- 동률은 같은 순위(경쟁 순위 1·1·3), 1위 동률은 `공동 1위`. `value: null`은 순위 밖으로 끝에 `산출 불가`.
- 강조는 하나: 1위 배지·기준선만 `highlightTone`, 막대는 회색, 글자는 텍스트 토큰만.
- 막대는 장식(`aria-hidden`), 보조기기는 `1위 대비 −512,100원 −6.0%` 텍스트를 읽는다.
- 1위 값이 0 이하이면 %를 적지 않는다(손실 기준의 %는 부호 뜻이 뒤집힌다). 0.0%로 반올림되는 차이는 `0.1% 미만`.
- 계산은 `gapsToBest(values, better)` 한 곳 — 앱이 같은 수치를 쓸 때 복사하지 말고 import한다.
